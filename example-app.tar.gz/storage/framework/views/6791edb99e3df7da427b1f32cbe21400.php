<button wire:click="$dispatch(&#039;destroyAction&#039;, JSON.parse(&#039;{\u0022event\u0022:{\u0022id\u0022:36,\u0022name\u0022:\u0022Recusandae quia omnis tempore.\u0022,\u0022description\u0022:\u0022Voluptas distinctio voluptatibus sit excepturi recusandae mollitia rerum. Quia quia et dolorem error. Vitae aut et consequatur velit ipsam aut. Eaque officiis et aperiam non natus dolorem.\u0022,\u0022date\u0022:\u00222008-07-21\u0022,\u0022location\u0022:\u0022Nowa S\\u00f3l\u0022,\u0022max_participants\u0022:20,\u0022created_at\u0022:\u00222025-02-18T20:31:07.000000Z\u0022,\u0022updated_at\u0022:\u00222025-02-18T20:31:07.000000Z\u0022,\u0022reservations_count\u0022:5}}&#039;))" class="text-gray-500" title="Usuń wydarzenie"><?php if (isset($component)) { $__componentOriginal8fb227d09011c9831b75a18671cea295 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8fb227d09011c9831b75a18671cea295 = $attributes; } ?>
<?php $component = WireUi\Components\Icon\Index::resolve(['name' => 'trash','mini' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wireui-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Icon\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8fb227d09011c9831b75a18671cea295)): ?>
<?php $attributes = $__attributesOriginal8fb227d09011c9831b75a18671cea295; ?>
<?php unset($__attributesOriginal8fb227d09011c9831b75a18671cea295); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8fb227d09011c9831b75a18671cea295)): ?>
<?php $component = $__componentOriginal8fb227d09011c9831b75a18671cea295; ?>
<?php unset($__componentOriginal8fb227d09011c9831b75a18671cea295); ?>
<?php endif; ?></button><?php /**PATH /var/www/html/storage/framework/views/13ffc1881c057b0a6278ae78635c5ded.blade.php ENDPATH**/ ?>