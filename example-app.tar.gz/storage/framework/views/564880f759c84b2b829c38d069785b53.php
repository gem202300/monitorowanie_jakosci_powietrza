<button wire:click="$dispatch(&#039;destroyAction&#039;, JSON.parse(&#039;{\u0022event\u0022:{\u0022id\u0022:10,\u0022name\u0022:\u0022Quidem dignissimos ipsa.\u0022,\u0022description\u0022:\u0022Corporis maxime rerum explicabo voluptas. Molestiae ipsum velit omnis expedita ut. Et laudantium et eos dolorem earum amet veritatis. Qui blanditiis omnis temporibus debitis libero.\u0022,\u0022date\u0022:\u00221982-11-09\u0022,\u0022location\u0022:\u0022Nowe Kramsko\u0022,\u0022max_participants\u0022:23,\u0022created_at\u0022:\u00222025-02-12T13:36:35.000000Z\u0022,\u0022updated_at\u0022:\u00222025-02-12T13:36:35.000000Z\u0022}}&#039;))" class="text-gray-500" title="events.actions.delete"><?php if (isset($component)) { $__componentOriginal8fb227d09011c9831b75a18671cea295 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8fb227d09011c9831b75a18671cea295 = $attributes; } ?>
<?php $component = WireUi\Components\Icon\Index::resolve(['name' => 'trash','mini' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wireui-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Icon\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8fb227d09011c9831b75a18671cea295)): ?>
<?php $attributes = $__attributesOriginal8fb227d09011c9831b75a18671cea295; ?>
<?php unset($__attributesOriginal8fb227d09011c9831b75a18671cea295); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8fb227d09011c9831b75a18671cea295)): ?>
<?php $component = $__componentOriginal8fb227d09011c9831b75a18671cea295; ?>
<?php unset($__componentOriginal8fb227d09011c9831b75a18671cea295); ?>
<?php endif; ?></button><?php /**PATH /var/www/html/storage/framework/views/c0b583d7e9e166f8568866e5eb08c255.blade.php ENDPATH**/ ?>