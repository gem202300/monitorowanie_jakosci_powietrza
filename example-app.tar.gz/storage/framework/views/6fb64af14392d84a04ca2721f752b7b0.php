<tr
    class="<?php echo e(data_get($theme, 'table.trBodyClass')); ?>"
    style="<?php echo e(data_get($theme, 'table.trBodyStyle')); ?>"
>
    <th
        class="<?php echo e(data_get($theme, 'table.tdBodyEmptyClass')); ?>"
        style="<?php echo e(data_get($theme, 'table.tdBodyEmptyStyle')); ?>"
        colspan="999"
    >
            <?php echo $this->processNoDataLabel(); ?>

    </th>
</tr>
<?php /**PATH /var/www/html/vendor/power-components/livewire-powergrid/src/Providers/../../resources/views/components/table/th-empty.blade.php ENDPATH**/ ?>