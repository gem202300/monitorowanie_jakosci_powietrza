<button wire:click="$dispatch(&#039;destroyAction&#039;, JSON.parse(&#039;{\u0022event\u0022:{\u0022id\u0022:2,\u0022name\u0022:\u0022Enim et quaerat.\u0022,\u0022description\u0022:\u0022Et qui rerum qui debitis iusto. Tempora sapiente in quam et saepe. Velit est quasi tempore similique consectetur culpa quaerat magnam. Amet et occaecati et harum eveniet eaque officiis.\u0022,\u0022date\u0022:\u00222014-09-02\u0022,\u0022location\u0022:\u0022P\\u0142az\\u00f3w\u0022,\u0022max_participants\u0022:21,\u0022created_at\u0022:\u00222025-02-18T20:31:07.000000Z\u0022,\u0022updated_at\u0022:\u00222025-02-18T20:31:07.000000Z\u0022,\u0022reservations_count\u0022:6}}&#039;))" class="text-gray-500" title="Usuń wydarzenie"><?php if (isset($component)) { $__componentOriginal8fb227d09011c9831b75a18671cea295 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8fb227d09011c9831b75a18671cea295 = $attributes; } ?>
<?php $component = WireUi\Components\Icon\Index::resolve(['name' => 'trash','mini' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wireui-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Icon\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8fb227d09011c9831b75a18671cea295)): ?>
<?php $attributes = $__attributesOriginal8fb227d09011c9831b75a18671cea295; ?>
<?php unset($__attributesOriginal8fb227d09011c9831b75a18671cea295); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8fb227d09011c9831b75a18671cea295)): ?>
<?php $component = $__componentOriginal8fb227d09011c9831b75a18671cea295; ?>
<?php unset($__componentOriginal8fb227d09011c9831b75a18671cea295); ?>
<?php endif; ?></button><?php /**PATH /var/www/html/storage/framework/views/68c6c1cb19b3b59dcde1e2a0c223b105.blade.php ENDPATH**/ ?>