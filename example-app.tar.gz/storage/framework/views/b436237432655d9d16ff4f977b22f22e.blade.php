<form target="_self" action="http://localhost/events/58/edit" method="post">
    @method("get")
    @csrf
    <button type="submit" class="text-gray-500"><x-wireui-icon name="pencil-square" class="w-5 h-5" mini /></button>
</form>